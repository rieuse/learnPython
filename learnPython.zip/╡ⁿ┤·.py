d = {'a': 1, 'b': 2, 'c': 3}
# 迭代key-value
for k,v in d.items():
    print(k,v)

#迭代value值
for value in d.values():
    print(value)

# 迭代key值
for key in d:
    print(key)