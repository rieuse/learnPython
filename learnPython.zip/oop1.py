class Oop (object):
    def foo(self):
        print("ok")
FO = Oop()
FO.foo()
