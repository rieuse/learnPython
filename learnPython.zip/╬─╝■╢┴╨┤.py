with open('读写.txt', 'a') as f:
    f.write('python3++')
