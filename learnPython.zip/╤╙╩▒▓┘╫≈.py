import time
print('开始程序')
time.sleep(4)
print('延时结束')