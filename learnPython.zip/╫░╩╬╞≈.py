import requests
def now():
    print('this is Python')
f = now
f()
print(now.__name__)