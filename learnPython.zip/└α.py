class Oneclass:
    a = 90
    def fo(self):
        return 'this class'
print(Oneclass.fo)